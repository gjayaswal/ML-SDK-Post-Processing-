package com.workfusion.ml.run;

import org.apache.commons.io.IOUtils;
import com.google.common.collect.Sets;
import com.workfusion.ml.Answer;
import com.workfusion.ml.run.stats.BlocksStatisticsCalculator;
import com.workfusion.ml.run.stats.BlocksStatisticsPrinter;
import com.workfusion.ml.util.CsvUtil;
import com.workfusion.ml.util.S3Manager;
import com.workfusion.nlp.uima.api.constant.View;
import com.workfusion.nlp.uima.workflow.model.Hypermodel;
import com.workfusion.nlp.uima.workflow.task.extract.IeCompositeAnnotatorResult;
import com.workfusion.vds.nlp.processing.normalization.OcrAmountNormalizer;
import com.workfusion.vds.nlp.uima.processing.run.IeProcessingRunner;
import org.apache.commons.lang3.StringUtils;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.util.FileUtils;
import org.cleartk.util.ViewUriUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiFunction;

public class ModelRunner extends IeProcessingRunner {

    private static final Logger logger = LoggerFactory.getLogger(ModelRunner.class);
    private static final String JSON = ".json";

    private static final String GOLD_FILE = "gold-file";

    private static final String COLUMN_FILENAME = "system_id";
    private static final String COLUMN_GOLD_HTML = "tagged_text";
    private static final String COLUMN_GOLD_BLOCKS = "ocr_result_html_blocks_gold";
    private static final String COLUMN_MODEL_BLOCKS = "ocr_result_html_blocks";

    private BlocksStatisticsCalculator calculator;

    public ModelRunner(Set<String> blockFields, Set<String> constantFields,
                       String mainGroupField,
                       Set<String> groupFields,
                       Map<String, BiFunction<String, String, Boolean>> fieldToComparison) {
        this.calculator = new BlocksStatisticsCalculator(blockFields, constantFields, mainGroupField, groupFields, fieldToComparison);
    }

    public static void main(String[] args) throws Exception {
        Set<String> blockFields = Sets.newHashSet(Answer.LOB, Answer.NO_LOSS_REPORTED);
        Set<String> constantFields = Sets.newHashSet(Answer.COMPANY_NAME, Answer.VALUATION_DATE);
        String mainGroupField = Answer.CLAIMS;
        Set<String> groupFields = Sets.newHashSet(Answer.LOSS_DATE, Answer.AMOUNT);

        Map<String, BiFunction<String, String, Boolean>> fieldToComparison = new HashMap<>();
        fieldToComparison.put(Answer.VALUATION_DATE, getDateComparison());
        fieldToComparison.put(Answer.LOSS_DATE, getDateComparison());
        fieldToComparison.put(Answer.AMOUNT, getNumericComparison());
        fieldToComparison.put(Answer.COMPANY_NAME, getCompanyComparison());
        fieldToComparison.put(Answer.LOB, getLobComparison());
        fieldToComparison.put(Answer.NO_LOSS_REPORTED, getNoLossReportedComparison());

        ModelRunner runner = new ModelRunner(blockFields, constantFields, mainGroupField, groupFields, fieldToComparison);

        Path trainedModelPath = Paths.get("C:\\LossRun\\AutomationTranningDataSet\\TrainedModel\\ocr_result_html_9108cccf-a3a7-4940-b5c6-894ec3e5aabe_HPO_10Hrs_9-Mar_2018\\output\\model");
        //Path inputFolderPath = Paths.get("/Users/pavel/Downloads/ml_sdk_assignment_2_1doc");
        Path outputFolderPath = Paths.get("C:\\LossRun\\metricsCalculation\\Results");
        Path inputCsvFilePath = Paths.get("C:\\Users\\Gjayaswal\\Downloads\\UnseentestSetFrom2_5_and_2_6_109Docs_extractedBYModel.CSV");

        //input csv 2 columns are required: id (file_name), gold html document content, gold blocks json
        runner.calculateStatistics(inputCsvFilePath, outputFolderPath);
    }

    @Override
    protected void extractAndPostProcess(Hypermodel model, Path input, Path output, AnalysisEngine pipeline) throws Exception {
        CsvUtil.getRecords(input.toString())
                .parallelStream()
                .forEach(record -> {
                            try {
                                Path rawExtractionResult = Paths.get(output.toString(), MODEL_RESULT, record.get(COLUMN_FILENAME) + JSON);
                                if (Files.exists(rawExtractionResult)) {
                                    processRawResults(rawExtractionResult, model, output);
                                } else {
                                    Path rawFile = Paths.get(output.toString(), GOLD_FILE, record.get(COLUMN_FILENAME) + JSON);
                                    Files.createDirectories(rawFile.getParent());
                                    Files.createFile(rawFile);
                                    FileUtils.saveString2File(record.get(COLUMN_GOLD_HTML), rawFile.toFile());
                                    JCas jCas = extract(pipeline, rawFile);
                                    JCas processingCas = postProcess(jCas, model);
                                    processResults(processingCas, output);
                                }
                            } catch (Exception e) {
                                logger.error("Error processing document " + record.get(COLUMN_FILENAME), e);
                            }
                        }
                );
    }

    private void processRawResults(Path rawExtractionResult, Hypermodel model, Path output) throws Exception {
        String extractionResults = new String(Files.readAllBytes(rawExtractionResult), StandardCharsets.UTF_8);
        IeCompositeAnnotatorResult result = IeCompositeAnnotatorResult.fromJson(extractionResults);

        AnalysisEngine pipeline = getPostProcessingPipeline(model);
        JCas jCas = pipeline.newJCas();
        JCasUtil.getView(jCas, View.RAW_SOURCE, true).setDocumentText(result.getTaggedText());
        JCasUtil.getView(jCas, View.RAW_RESULTS, true).setDocumentText(extractionResults);
        ViewUriUtil.setURI(jCas, rawExtractionResult.toUri());
        pipeline.process(jCas);

        processResults(jCas, output);
    }

    private void processResults(JCas jCas, Path output) throws Exception {
        String rawExtraction = JCasUtil.getView(jCas, View.RAW_RESULTS, true).getDocumentText();

        String finalResult = jCas.getView(View.FINAL_RESULTS).getDocumentText();

        Path rawExtractFolder = Paths.get(output.toString(), MODEL_RESULT);
        Path finalResultFolder = Paths.get(output.toString(), PROCESSING_RESULT);


        String fileName = getFileName(jCas);
        String originalFileName = fileName;
        if (!fileName.endsWith(JSON)) {
            fileName = fileName + JSON;
        } else {
            originalFileName = fileName.replace(JSON, "");
        }
        if (!StringUtils.isBlank(rawExtraction)) {
            rawExtractFolder.toFile().mkdirs();
            Files.write(Paths.get(rawExtractFolder.toString(), fileName), rawExtraction.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE);
            IeCompositeAnnotatorResult modelResult = IeCompositeAnnotatorResult.fromJson(rawExtraction);
            Files.write(Paths.get(rawExtractFolder.toString(), originalFileName), modelResult.getTaggedText().getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE);
        }

        finalResultFolder.toFile().mkdirs();
        Path finalResultFile = Paths.get(finalResultFolder.toString(), fileName);
        Files.deleteIfExists(finalResultFile);
        Files.write(finalResultFile, finalResult.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE);
        Path finalHtmlResultFile = Paths.get(finalResultFolder.toString(), originalFileName);
        Files.deleteIfExists(finalHtmlResultFile);
        IeCompositeAnnotatorResult processingResult = IeCompositeAnnotatorResult.fromJson(finalResult);
        Files.write(finalHtmlResultFile, processingResult.getTaggedText().getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE);
    }

    private JCas postProcess(JCas rawCas, Hypermodel model) throws Exception {
        AnalysisEngine pipeline = getPostProcessingPipeline(model);
        JCas processingCas = pipeline.newJCas();
        ViewUriUtil.setURI(processingCas, ViewUriUtil.getURI(rawCas));
        JCasUtil.getView(processingCas, View.RAW_SOURCE, true).setDocumentText(JCasUtil.getView(rawCas, View.RAW_SOURCE, false).getDocumentText());
        JCasUtil.getView(processingCas, View.RAW_RESULTS, true).setDocumentText(JCasUtil.getView(rawCas, View.FINAL_RESULTS, false).getDocumentText());
        pipeline.process(processingCas);
        return processingCas;
    }

    protected void calculateStatistics(Path input, Path output) throws Exception {
        /*
        1. Get gold json
        2. Get post_processed json from json
        3. Go through each block on both sides and create empty block on other side if missing
         */
        List<Map<String, String>> fieldLevelStats = new LinkedList<>();
        List<Map<String, String>> groupLevelStats = new LinkedList<>();
        List<Map<String, String>> blockLevelStats = new LinkedList<>();
        List<Map<String, String>> documentLevelStats = new LinkedList<>();
        List<Map<String, String>> documentLevelStatsIgnoringBlocks = new LinkedList<>();

        AtomicInteger counter = new AtomicInteger();

        CsvUtil.getRecords(input.toString())
                .forEach(record -> {
                    try {
//                        String goldContent = record.get(COLUMN_GOLD_HTML);
//                        String goldFileName = record.get(COLUMN_FILENAME);

                        String goldBlocks = record.get(COLUMN_GOLD_BLOCKS);

                        //Path extractedResultPath = Paths.get(extract.toString(), goldFileName + JSON);
                        //String extractedResult = new String(Files.readAllBytes(extractedResultPath), StandardCharsets.UTF_8);
                        //String extractedDocument = IeCompositeAnnotatorResult.fromJson(extractedResult).getTaggedText();

//                        Path processedResultPath = Paths.get(processed.toString(), goldFileName + JSON);
//                        String processedResult = new String(Files.readAllBytes(processedResultPath), StandardCharsets.UTF_8);
//                        System.out.println("json: " + processedResult);
                        String processedBlocks = record.get(COLUMN_MODEL_BLOCKS);

                        S3Manager s3Manager = new S3Manager();
                        String key = record.get(COLUMN_FILENAME) + ".html";
                        record.put("ocr_result_html_tagged_gold", s3Manager.put("aig-data", "TaggedData/gold-tagged/" + key, IOUtils.toInputStream(record.get("ocr_result_html_tagged_gold")), "text/html"));
                        record.put("ocr_result_html_tagged", s3Manager.put("aig-data", "TaggedData/model-tagged/" + key, IOUtils.toInputStream(record.get("ocr_result_html_tagged")), "text/html"));

                        List<Map<String, String>> fieldStats = calculator.fieldLevelStats(goldBlocks, processedBlocks);
                        enrichStats(record, fieldStats);
                        fieldLevelStats.addAll(fieldStats);

                        List<Map<String, String>> groupStats = calculator.groupLevelStats(goldBlocks, processedBlocks);
                        enrichStats(record, groupStats);
                        groupLevelStats.addAll(groupStats);

                        List<Map<String, String>> blockStats = calculator.blockLevelStats(goldBlocks, processedBlocks);
                        enrichStats(record, blockStats);
                        blockLevelStats.addAll(blockStats);

                        List<Map<String, String>> documentStats = calculator.documentLevelStats(goldBlocks, processedBlocks);
                        enrichStats(record, documentStats);
                        documentLevelStats.addAll(documentStats);

                        List<Map<String, String>> documentStatsIgnoreBlocking = calculator.documentLevelStatsIgnoreBlocking(goldBlocks, processedBlocks);
                        enrichStats(record, documentStatsIgnoreBlocking);
                        documentLevelStatsIgnoringBlocks.addAll(documentStatsIgnoreBlocking);

                        System.out.println("processed documents: " + counter.incrementAndGet());

                    } catch (Exception e) {
                        logger.error("Error calculating stats for file " + record.get(COLUMN_FILENAME), e);
                    }
                });
        BlocksStatisticsPrinter.print(fieldLevelStats, output, "field");
        BlocksStatisticsPrinter.printMetrics(fieldLevelStats, output, "field");

        BlocksStatisticsPrinter.print(groupLevelStats, output, "claim");
        BlocksStatisticsPrinter.printMetrics(groupLevelStats, output, "claim");

        BlocksStatisticsPrinter.print(blockLevelStats, output, "block");
        BlocksStatisticsPrinter.printMetrics(blockLevelStats, output, "block");

        BlocksStatisticsPrinter.print(documentLevelStats, output, "document");
        BlocksStatisticsPrinter.printMetrics(documentLevelStats, output, "document");

        BlocksStatisticsPrinter.print(documentLevelStatsIgnoringBlocks, output, "document_ignore_blocks");
        BlocksStatisticsPrinter.printMetrics(documentLevelStatsIgnoringBlocks, output, "document_ignore_blocks");
    }

    private List<Map<String, String>> enrichStats(Map<String, String> record, List<Map<String, String>> stats) throws UnsupportedEncodingException {
        for (Map<String, String> stat : stats) {
            stat.put(COLUMN_GOLD_BLOCKS, record.get(COLUMN_GOLD_BLOCKS));
            stat.put(COLUMN_MODEL_BLOCKS, record.get(COLUMN_MODEL_BLOCKS));
            stat.put("system_id", record.get("system_id"));
            stat.put("document_link", record.get("document_link"));
            stat.put("ocr_result_html", record.get("ocr_result_html"));
            stat.put("ocr_result_html_tagged_gold", record.get("ocr_result_html_tagged_gold"));
            stat.put("ocr_result_html_tagged", record.get("ocr_result_html_tagged"));
        }
        return stats;
    }

    private static BiFunction<String, String, Boolean> getNumericComparison() {
        return (s1, s2) -> {
            s1 = naToEmpty(s1);
            s2 = naToEmpty(s2);
            if (s1.isEmpty() && s2.isEmpty()) {
                return true;
            }
            OcrAmountNormalizer n = new OcrAmountNormalizer();
            BigDecimal bd1 = n.parseNumber(s1);
            BigDecimal bd2 = n.parseNumber(s2);
            if (bd1 != null && bd2 != null && bd1.compareTo(bd2) == 0) {
                return true;
            }
            return false;

        };
    }

    private static BiFunction<String, String, Boolean> getDateComparison() {
        return (s1, s2) -> {
            s1 = naToEmpty(s1);
            s2 = naToEmpty(s2);
            if (s1.isEmpty() && s2.isEmpty()) {
                return true;
            }
            if (s1.matches("(\\d{1,2}/)?\\d{1,2}/\\d{2,4}") && s2.matches("(\\d{1,2}/)?\\d{1,2}/\\d{2,4}")) {
                LocalDate ld1 = LocalDate.parse(s1, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
                LocalDate ld2 = LocalDate.parse(s2, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
                if (ld1.compareTo(ld2) == 0) {
                    return true;
                }
            }
            return false;
        };
    }

    private static BiFunction<String, String, Boolean> getCompanyComparison() {
        return (s1, s2) -> {
            s1 = naToEmpty(s1);
            s2 = naToEmpty(s2);
            s1 = s1.replaceAll("&#039;", "");
            s2 = s2.replaceAll("&#039;", "");
            s1 = s1.replaceAll("[^0-9A-Za-z]", "");
            s2 = s2.replaceAll("[^0-9A-Za-z]", "");
            return s1.equalsIgnoreCase(s2);

        };
    }

    private static BiFunction<String, String, Boolean> getLobComparison() {
        return (s1, s2) -> {
            s1 = naToEmpty(s1);
            s2 = naToEmpty(s2);
            s1 = s1.replaceAll("[^0-9A-Za-z]", "");
            s2 = s2.replaceAll("[^0-9A-Za-z]", "");
            return s1.equalsIgnoreCase(s2);

        };
    }

    private static String naToEmpty(String s) {
        if ("n/a".equalsIgnoreCase(s)) {
            s = "";
        }
        return s;
    }

    private static BiFunction<String, String, Boolean> getNoLossReportedComparison() {
        return (s1, s2) -> {
            s1 = naToEmpty(s1);
            s2 = naToEmpty(s2);
            return s1.equalsIgnoreCase(s2);
        };
    }
}
