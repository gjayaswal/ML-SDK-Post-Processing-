package com.workfusion.ml.run.stats;

import com.google.gson.reflect.TypeToken;
import com.workfusion.nlp.uima.api.constant.HtmlTagAttr;
import com.workfusion.nlp.uima.util.GsonUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

public class BlocksStatisticsCalculator {

    private static final String MISSING_AMOUNT_ATTRIBUTE = "missing_size";

    private Set<String> blockFields;
    private Set<String> constantFields;
    private String mainGroupField;
    private Set<String> groupFields;
    private Map<String, BiFunction<String, String, Boolean>> fieldToComparison;

    public BlocksStatisticsCalculator(Set<String> blockFields, Set<String> constantFields,
                                      String mainGroupField,
                                      Set<String> groupFields,
                                      Map<String, BiFunction<String, String, Boolean>> fieldToComparison) {
        this.blockFields = blockFields;
        this.constantFields = constantFields;
        this.mainGroupField = mainGroupField;
        this.groupFields = groupFields;
        this.fieldToComparison = fieldToComparison;
    }

    public List<Map<String, String>> balancedFieldLevelStats(String goldBlocksJson, String postProcessedBlocksJson) {
        List<Map<String, Object>> goldBlocks = readBlocksFromJson(goldBlocksJson);
        List<Map<String, Object>> processedBlocks = readBlocksFromJson(postProcessedBlocksJson);

        prepareBlocksAndGroups(goldBlocks, processedBlocks);

        List<Map<String, String>> statRecords = new LinkedList<>();

        for (int i = 0; i < goldBlocks.size(); i++) {
            Map<String, Object> goldBlock = goldBlocks.get(i);
            Map<String, Object> processedBlock = processedBlocks.get(i);

            System.out.println("gold: " + goldBlock);
            System.out.println("processed: " + processedBlock);

            if (i == 0) {
                for (String constantField : constantFields) {
                    Map<String, String> result =
                            createResult(constantField, goldBlock.get(constantField).toString(),
                                    processedBlock.get(constantField).toString(),
                                    new FieldMatcher(fieldToComparison, constantField), fieldEmptyChecker);
                    result.put("field", constantField);
                    statRecords.add(result);
                }
            }

            for (String blockField : blockFields) {
                Map<String, String> result =
                        createResult(blockField, goldBlock.get(blockField).toString(),
                                processedBlock.get(blockField).toString(),
                                new FieldMatcher(fieldToComparison, blockField), fieldEmptyChecker);
                result.put("field", blockField);
                result.put(HtmlTagAttr.BLOCK_NUMBER, String.valueOf(i));
                statRecords.add(result);
            }

            List<Map<String, String>> goldBlockGroups = getGroupsForBlock(goldBlock);
            List<Map<String, String>> processedBlockGroups = getGroupsForBlock(processedBlock);

            for (int j = 0; j < goldBlockGroups.size(); j++) {
                Map<String, String> goldGroup = goldBlockGroups.get(j);
                Map<String, String> processedGroup = processedBlockGroups.get(j);
                for (String groupField : groupFields) {
                    Map<String, String> result =
                            createResult(groupField, goldGroup.get(groupField), processedGroup.get(groupField),
                                    new FieldMatcher(fieldToComparison, groupField), fieldEmptyChecker);
                    result.put("field", groupField);
                    result.put(HtmlTagAttr.BLOCK_NUMBER, String.valueOf(i));
                    result.put(HtmlTagAttr.TAB_NUMBER, String.valueOf(j));
                    statRecords.add(result);
                }
            }
        }

        return statRecords;
    }

    public List<Map<String, String>> fieldLevelStats(String goldBlocksJson, String postProcessedBlocksJson) {
        List<Map<String, Object>> goldBlocks = readBlocksFromJson(goldBlocksJson);
        List<Map<String, Object>> processedBlocks = readBlocksFromJson(postProcessedBlocksJson);

        prepareBlocksAndGroups(goldBlocks, processedBlocks);

        List<Map<String, String>> statRecords = new LinkedList<>();

        for (String field : constantFields) {
            LinkedList<String> extractedValues = processedBlocks.stream().limit(1).map(b -> b.get(field).toString()).distinct()
                    .collect(Collectors.toCollection(LinkedList::new));
            LinkedList<String> goldValues = goldBlocks.stream().limit(1).map(b -> b.get(field).toString()).distinct()
                    .collect(Collectors.toCollection(LinkedList::new));
            statRecords.addAll(processField(field, goldValues, extractedValues));
        }

        for (String field : blockFields) {
            LinkedList<String> extractedValues = processedBlocks.stream().map(b -> b.get(field).toString())
                    .collect(Collectors.toCollection(LinkedList::new));
            LinkedList<String> goldValues = goldBlocks.stream().map(b -> b.get(field).toString())
                    .collect(Collectors.toCollection(LinkedList::new));
            statRecords.addAll(processField(field, goldValues, extractedValues));
        }

        for (String field : groupFields) {
            LinkedList<String> extractedValues = processedBlocks.stream().map(this::getGroupsForBlock)
                    .flatMap(Collection::stream)
                    .map(m -> m.get(field))
                    .collect(Collectors.toCollection(LinkedList::new));
            LinkedList<String> goldValues = goldBlocks.stream().map(this::getGroupsForBlock)
                    .flatMap(Collection::stream)
                    .map(m -> m.get(field))
                    .collect(Collectors.toCollection(LinkedList::new));
            statRecords.addAll(processField(field, goldValues, extractedValues));
        }

        return statRecords;
    }

    public List<Map<String, String>> groupLevelStats(String goldBlocksJson, String postProcessedBlocksJson) {
        List<Map<String, Object>> goldBlocks = readBlocksFromJson(goldBlocksJson);
        List<Map<String, Object>> processedBlocks = readBlocksFromJson(postProcessedBlocksJson);

        prepareBlocksAndGroups(goldBlocks, processedBlocks);

        List<Map<String, String>> statRecords = new LinkedList<>();

        LinkedList<Map<String, String>> extractedGroups = processedBlocks.stream().map(this::getGroupsForBlock)
                .flatMap(Collection::stream)
                .collect(Collectors.toCollection(LinkedList::new));
        LinkedList<Map<String, String>> goldGroups = goldBlocks.stream().map(this::getGroupsForBlock)
                .flatMap(Collection::stream)
                .collect(Collectors.toCollection(LinkedList::new));

        List<Map<String, String>> toRemoveExtracted = new LinkedList<>(extractedGroups);

        for (Map<String, String> extractedGroup : extractedGroups) {
            for (Map<String, String> goldGroup : goldGroups) {
                if (!groupMatches.apply(goldGroup, extractedGroup).getResult()) {
                    continue;
                }
                goldGroups.remove(goldGroup);
                toRemoveExtracted.remove(extractedGroup);
                statRecords.add(createResult("group", goldGroup, extractedGroup, groupMatches, groupEmptyChecker));
                break;
            }
        }
        for (int i = 0; i < toRemoveExtracted.size(); i++) {
            statRecords.add(createResult("group", goldGroups.get(i), toRemoveExtracted.get(i), groupMatches, groupEmptyChecker));
        }

        return statRecords;
    }

    public List<Map<String, String>> blockLevelStats(String goldBlocksJson, String postProcessedBlocksJson) {
        List<Map<String, Object>> goldBlocks = new LinkedList<>(readBlocksFromJson(goldBlocksJson));
        List<Map<String, Object>> processedBlocks = new LinkedList<>(readBlocksFromJson(postProcessedBlocksJson));

        prepareBlocksAndGroups(goldBlocks, processedBlocks);

        List<Map<String, Object>> toRemoveProcessedBlocks = new LinkedList<>(processedBlocks);

        List<Map<String, String>> statRecords = new LinkedList<>();

        for (Map<String, Object> processedBlock : processedBlocks) {
            for (Map<String, Object> goldBlock : goldBlocks) {
                if (!blockMatches.apply(goldBlock, processedBlock).getResult()) {
                    continue;
                }
                toRemoveProcessedBlocks.remove(processedBlock);
                goldBlocks.remove(goldBlock);
                statRecords.add(createResult("block", goldBlock, processedBlock, blockMatches, blockEmptyChecker));
                break;
            }
        }
        for (int i = 0; i < toRemoveProcessedBlocks.size(); i++) {
            statRecords.add(createResult("block", goldBlocks.get(i), toRemoveProcessedBlocks.get(i), blockMatches, blockEmptyChecker));
        }


        return statRecords;
    }

    public List<Map<String, String>> documentLevelStats(String goldBlocksJson, String postProcessedBlocksJson) {
        List<Map<String, Object>> goldBlocks = new LinkedList<>(readBlocksFromJson(goldBlocksJson));
        int goldSize = goldBlocks.size();
        List<Map<String, Object>> processedBlocks = new LinkedList<>(readBlocksFromJson(postProcessedBlocksJson));
        int extractedSize = processedBlocks.size();

        prepareBlocksAndGroups(goldBlocks, processedBlocks);

        List<Map<String, String>> statRecords = new LinkedList<>();

        Map<String, String> documentResult = createResult("document", goldBlocks, processedBlocks, documentMatches, documentEmptyChecker);
        documentResult.put("gold_blocks_amount", String.valueOf(goldSize));
        documentResult.put("extracted_blocks_amount", String.valueOf(extractedSize));
        statRecords.add(documentResult);

        return statRecords;
    }

    public List<Map<String, String>> documentLevelStatsIgnoreBlocking(String goldBlocksJson, String postProcessedBlocksJson) {
        List<Map<String, Object>> goldBlocks = new LinkedList<>(readBlocksFromJson(goldBlocksJson));
        List<Map<String, Object>> processedBlocks = new LinkedList<>(readBlocksFromJson(postProcessedBlocksJson));

        prepareBlocksAndGroups(goldBlocks, processedBlocks);

        List<Map<String, String>> statRecords = new LinkedList<>();

        Map<String, String> documentResult = createResult("document", goldBlocks, processedBlocks, documentMatchesIgnoreBlocks, documentEmptyCheckerIgnoreBlocks);

        statRecords.add(documentResult);

        return statRecords;
    }

    private List<Map<String, String>> processField(String field, LinkedList<String> goldValues, LinkedList<String> extractedValues) {
        List<Map<String, String>> statRecords = new LinkedList<>();

        List<String> toRemoveExtracted = new LinkedList<>(extractedValues);

        for (String extractedValue : extractedValues) {
            for (String goldValue : goldValues) {
                if (!fieldMatches(field, goldValue, extractedValue)) {
                    continue;
                }
                toRemoveExtracted.remove(extractedValue);
                goldValues.remove(goldValue);
                Map<String, String> result = createResult(field, goldValue, extractedValue, new FieldMatcher(fieldToComparison, field), fieldEmptyChecker);
                result.put("field", field);
                statRecords.add(result);
                break;
            }
        }
        for (int i = 0; i < toRemoveExtracted.size(); i++) {
            Map<String, String> result = createResult(field, goldValues.get(i), toRemoveExtracted.get(i), new FieldMatcher(fieldToComparison, field), fieldEmptyChecker);
            result.put("field", field);
            statRecords.add(result);
        }
        return statRecords;
    }

    private void prepareBlocksAndGroups(List<Map<String, Object>> goldBlocks, List<Map<String, Object>> processedBlocks) {
        int maxBlocks = levelUpBlocks(goldBlocks, processedBlocks);

        for (int i = 0; i < maxBlocks; i++) {
            Map<String, Object> goldBlock = goldBlocks.get(i);
            Map<String, Object> processedBlock = processedBlocks.get(i);

            List<Map<String, String>> goldBlockGroups = getGroupsForBlock(goldBlock);
            List<Map<String, String>> processedBlockGroups = getGroupsForBlock(processedBlock);

            levelUpGroups(goldBlockGroups, processedBlockGroups);
        }
    }

    private void levelUpGroups(List<Map<String, String>> goldBlockGroups, List<Map<String, String>> processedBlockGroups) {
        int maxGroups = Math.max(goldBlockGroups.size(), processedBlockGroups.size());
        for (int j = goldBlockGroups.size(); j < maxGroups; j++) {
            goldBlockGroups.add(createEmptyGroup(groupFields));
        }
        for (int j = processedBlockGroups.size(); j < maxGroups; j++) {
            processedBlockGroups.add(createEmptyGroup(groupFields));
        }
        for (int i = 0; i < processedBlockGroups.size(); i++) {
            for (String groupField : groupFields) {
                processedBlockGroups.get(i).putIfAbsent(groupField, StringUtils.EMPTY);
                goldBlockGroups.get(i).putIfAbsent(groupField, StringUtils.EMPTY);
            }
        }
    }

    private int levelUpBlocks(List<Map<String, Object>> goldBlocks, List<Map<String, Object>> processedBlocks) {
        int maxBlocks = Math.max(goldBlocks.size(), processedBlocks.size());
        for (int i = goldBlocks.size(); i < maxBlocks; i++) {
            goldBlocks.add(createEmptyBlock(blockFields));
        }
        for (int i = processedBlocks.size(); i < maxBlocks; i++) {
            processedBlocks.add(createEmptyBlock(blockFields));
        }
        for (int i = 0; i < processedBlocks.size(); i++) {
            for (String blockField : blockFields) {
                processedBlocks.get(i).putIfAbsent(blockField, StringUtils.EMPTY);
                goldBlocks.get(i).putIfAbsent(blockField, StringUtils.EMPTY);
            }
            for (String blockField : constantFields) {
                processedBlocks.get(i).putIfAbsent(blockField, StringUtils.EMPTY);
                goldBlocks.get(i).putIfAbsent(blockField, StringUtils.EMPTY);
            }
            processedBlocks.get(i).putIfAbsent(mainGroupField, new ArrayList<Map<String, String>>());
            goldBlocks.get(i).putIfAbsent(mainGroupField, new ArrayList<Map<String, String>>());
        }
        return maxBlocks;
    }

    private List<Map<String, Object>> readBlocksFromJson(String blocksJson) {
        return GsonUtils.GSON.fromJson(blocksJson, new TypeToken<List<Map<String, Object>>>() {
        }.getType());
    }

    private Function<String, Boolean> fieldEmptyChecker = value ->
            !StringUtils.isNotEmpty(value) && !"n/a".equals(value);

    private Function<Map<String, String>, Boolean> groupEmptyChecker = group -> {
        for (String field : group.keySet()) {
            if (!fieldEmptyChecker.apply(group.get(field))) {
                return false;
            }
        }
        return true;
    };

    private Function<Map<String, Object>, Boolean> blockEmptyChecker = block -> {
        for (String blockField : blockFields) {
            if (!fieldEmptyChecker.apply(block.get(blockField).toString())) {
                return false;
            }
        }
        for (Map<String, String> group : getGroupsForBlock(block)) {
            if (!groupEmptyChecker.apply(group)) {
                return false;
            }
        }
        return true;
    };

    private Function<List<Map<String, Object>>, Boolean> documentEmptyChecker = blocks -> {
        if (blocks.size() > 0) {
            for (String constantField : constantFields) {
                if (!fieldEmptyChecker.apply(blocks.get(0).get(constantField).toString())) {
                    return false;
                }
            }
        }

        for (Map<String, Object> block : blocks) {
            if (!blockEmptyChecker.apply(block)) {
                return false;
            }
        }
        return true;
    };

    private Function<List<Map<String, Object>>, Boolean> documentEmptyCheckerIgnoreBlocks = blocks -> {
        if (blocks.size() > 0) {
            for (String constantField : constantFields) {
                if (!fieldEmptyChecker.apply(blocks.get(0).get(constantField).toString())) {
                    return false;
                }
            }

            for (String blockField : blockFields) {
                List<String> blockFieldValues = blocks.stream().map(b -> b.get(blockField).toString()).collect(Collectors.toList());
                for (String blockFieldValue : blockFieldValues) {
                    if (!fieldEmptyChecker.apply(blockFieldValue)) {
                        return false;
                    }
                }
            }
        }

        List<Map<String, String>> groups = blocks.stream().flatMap(b -> getGroupsForBlock(b).stream()).collect(Collectors.toList());
        for (Map<String, String> group : groups) {
            if (!groupEmptyChecker.apply(group)) {
                return false;
            }
        }
        return true;
    };

    private boolean fieldMatches(String field, String gold, String processed) {
        return new FieldMatcher(fieldToComparison, field).apply(gold, processed).getResult();
    }

    private BiFunction<Map<String, String>, Map<String, String>, ComparisonResult> groupMatches = (goldGroup, processedGroup) -> {
        for (String field : processedGroup.keySet()) {
            if (!fieldMatches(field, goldGroup.get(field), processedGroup.get(field))) {
                return new ComparisonResult(false);
            }
        }
        return new ComparisonResult(true);
    };

    private BiFunction<Map<String, Object>, Map<String, Object>, ComparisonResult> blockMatches = (goldBlock, processedBlock) -> {
        for (String blockField : blockFields) {
            if (!fieldMatches(blockField, goldBlock.get(blockField).toString(), processedBlock.get(blockField).toString())) {
                return new ComparisonResult(false);
            }
        }
        List<Map<String, String>> goldGroups = new LinkedList<>(getGroupsForBlock(goldBlock));
        List<Map<String, String>> processedGroups = new LinkedList<>(getGroupsForBlock(processedBlock));

        return allMatch(goldGroups, processedGroups, groupMatches);
    };

    private BiFunction<List<Map<String, Object>>, List<Map<String, Object>>, ComparisonResult> documentMatches = (goldBlocks, processedBlocks) -> {
        goldBlocks = new LinkedList<>(goldBlocks);
        processedBlocks = new LinkedList<>(processedBlocks);

        for (String constantField : constantFields) {
            if (!fieldMatches(constantField, goldBlocks.get(0).get(constantField).toString(), processedBlocks.get(0).get(constantField).toString())) {
                return new ComparisonResult(false);
            }
        }

        return allMatch(goldBlocks, processedBlocks, blockMatches);
    };

    private BiFunction<List<Map<String, Object>>, List<Map<String, Object>>, ComparisonResult> documentMatchesIgnoreBlocks = (goldBlocks, processedBlocks) -> {
        goldBlocks = new LinkedList<>(goldBlocks);
        processedBlocks = new LinkedList<>(processedBlocks);

        ComparisonResult comparisonResult = new ComparisonResult(true);
        for (String constantField : constantFields) {
            comparisonResult.putAttribute(constantField + "_match", "1");
        }
        for (String blockField : blockFields) {
            comparisonResult.putAttribute("all_" + blockField + "_match", "1");
        }
        comparisonResult.putAttribute("groups_match", "1");
        comparisonResult.putAttribute("groups_" + MISSING_AMOUNT_ATTRIBUTE, "0");

        if (processedBlocks.size() > 0) {
            for (String constantField : constantFields) {
                if (!fieldMatches(constantField, goldBlocks.get(0).get(constantField).toString(), processedBlocks.get(0).get(constantField).toString())) {
                    comparisonResult.putAttribute(constantField + "_match", "0");
                    comparisonResult.setResult(false);
                }
            }

            for (String blockField : blockFields) {
                List<String> processedBlockFieldValues = processedBlocks.stream().map(b -> b.get(blockField).toString()).collect(Collectors.toList());
                List<String> goldBlockFieldValues = goldBlocks.stream().map(b -> b.get(blockField).toString()).collect(Collectors.toList());

                if (!allMatch(goldBlockFieldValues, processedBlockFieldValues, new FieldMatcher(fieldToComparison, blockField)).getResult()) {
                    comparisonResult.setResult(false);
                    comparisonResult.putAttribute("all_" + blockField + "_match", "0");
                }
            }
        }

        List<Map<String, String>> goldGroups = goldBlocks.stream().flatMap(b -> getGroupsForBlock(b).stream()).collect(Collectors.toList());
        List<Map<String, String>> processedGroups = processedBlocks.stream().flatMap(b -> getGroupsForBlock(b).stream()).collect(Collectors.toList());
        comparisonResult.putAttribute("gold_groups_size", String.valueOf(goldGroups.stream().filter(g -> !groupEmptyChecker.apply(g)).count()));
        comparisonResult.putAttribute("extracted_groups_size", String.valueOf(processedGroups.stream().filter(g -> !groupEmptyChecker.apply(g)).count()));

        ComparisonResult groupsComparisonResult = allMatch(goldGroups, processedGroups, groupMatches);
        if (!groupsComparisonResult.getResult()) {
            comparisonResult.putAttribute("groups_match", "0");
            comparisonResult.setResult(false);
            comparisonResult.putAttribute("groups_" + MISSING_AMOUNT_ATTRIBUTE, groupsComparisonResult.getAttributes().get(MISSING_AMOUNT_ATTRIBUTE));
        }

        return comparisonResult;
    };



    private List<Map<String, String>> getGroupsForBlock(Map<String, Object> block) {
        return (List<Map<String, String>>) block.getOrDefault(mainGroupField, new LinkedList<Map<String, String>>());
    }

    private Map<String, Object> createEmptyBlock(Set<String> blockFields) {
        Map<String, Object> block = new LinkedHashMap<>();
        for (String blockField : blockFields) {
            block.put(blockField, StringUtils.EMPTY);
        }
        for (String constantField : constantFields) {
            block.put(constantField, StringUtils.EMPTY);
        }
        block.put(mainGroupField, new ArrayList<Map<String, String>>());
        return block;
    }

    private Map<String, String> createEmptyGroup(Set<String> groupFields) {
        Map<String, String> group = new LinkedHashMap<>();
        for (String groupField : groupFields) {
            group.put(groupField, StringUtils.EMPTY);
        }
        return group;
    }

    private static String naToEmpty(String s) {
        if ("n/a".equalsIgnoreCase(s)) {
            s = "";
        }
        return s;
    }

    private <T extends List<U>, U> ComparisonResult allMatch(T goldList, T extractedList, BiFunction<U, U, ComparisonResult> compare) {
        List<U> goldListCopy = new LinkedList<>(goldList);
        List<U> extractedListCopy = new LinkedList<>(extractedList);

        List<U> extractedToRemove = new LinkedList<>();

        int matchesFound = 0;

        for (U extracted : extractedListCopy) {
            for (U gold : goldListCopy) {
                if (!compare.apply(gold, extracted).getResult()) {
                    continue;
                }
                goldListCopy.remove(gold);
                matchesFound++;
                break;
            }
        }

        ComparisonResult comparisonResult = new ComparisonResult(extractedList.size() == matchesFound);
        comparisonResult.putAttribute(MISSING_AMOUNT_ATTRIBUTE, String.valueOf(extractedList.size() - matchesFound));
        return comparisonResult;
    }

    private <T> Map<String, String> createResult(String field, T gold, T processed, BiFunction<T, T, ComparisonResult> compare,
                                                 Function<T, Boolean> emptyChecker) {
        Map<String, String> resultRecord = new LinkedHashMap<>();
        resultRecord.put("gold", gold.toString());
        resultRecord.put("extracted", processed.toString());
        resultRecord.put("tp", "0");
        resultRecord.put("fp", "0");
        resultRecord.put("fn", "0");
        resultRecord.put("tn", "0");
        resultRecord.put("field", field);

        ComparisonResult result = compare.apply(gold, processed);
        resultRecord.putAll(result.getAttributes());
        boolean matches = result.getResult();
        if (matches) {
            if (emptyChecker.apply(gold)) {
                resultRecord.put("tn", "1");
            } else {
                resultRecord.put("tp", "1");
            }
        } else {
            if (emptyChecker.apply(gold)) {
                resultRecord.put("fp", "1");
            } else if (emptyChecker.apply(processed)) {
                resultRecord.put("fn", "1");
            } else {
                resultRecord.put("fp", "1");
                resultRecord.put("fn", "1");
            }
        }
        return resultRecord;
    }

    private static class FieldMatcher implements BiFunction<String, String, ComparisonResult> {
        private Map<String, BiFunction<String, String, Boolean>> fieldToComparison;
        private String field;

        FieldMatcher(Map<String, BiFunction<String, String, Boolean>> fieldToComparison, String field) {
            this.fieldToComparison = fieldToComparison;
            this.field = field;
        }

        @Override
        public ComparisonResult apply(String s, String s2) {
            s = naToEmpty(s);
            s2 = naToEmpty(s2);
            BiFunction<String, String, Boolean> comparison = fieldToComparison.getOrDefault(field, String::equalsIgnoreCase);
            return new ComparisonResult(comparison.apply(s, s2));
        }
    }

    private static class ComparisonResult {
        private Boolean result;
        private Map<String, String> attributes = new LinkedHashMap<>();

        public ComparisonResult(Boolean result) {
            this.result = result;
        }

        public ComparisonResult(Boolean result, Map<String, String> attributes) {
            this.result = result;
            this.attributes = attributes;
        }

        public Boolean getResult() {
            return result;
        }

        public void setResult(Boolean result) {
            this.result = result;
        }

        public Map<String, String> getAttributes() {
            return attributes;
        }

        public void putAttribute(String key, String value) {
            attributes.put(key, value);
        }
    }
}
