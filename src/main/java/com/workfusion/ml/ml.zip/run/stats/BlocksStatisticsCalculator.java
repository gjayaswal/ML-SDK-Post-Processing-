package com.workfusion.ml.run.stats;

import com.google.gson.reflect.TypeToken;
import com.workfusion.nlp.uima.api.constant.HtmlTagAttr;
import com.workfusion.nlp.uima.util.GsonUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.BiFunction;

public class BlocksStatisticsCalculator {

    Set<String> blockFields;
    Set<String> constantFields;
    String mainGroupField;
    Set<String> groupFields;
    Map<String, BiFunction<String, String, Boolean>> fieldToComparison;

    public BlocksStatisticsCalculator(Set<String> blockFields, Set<String> constantFields,
                                      String mainGroupField,
                                      Set<String> groupFields,
                                      Map<String, BiFunction<String, String, Boolean>> fieldToComparison) {
        this.blockFields = blockFields;
        this.constantFields = constantFields;
        this.mainGroupField = mainGroupField;
        this.groupFields = groupFields;
        this.fieldToComparison = fieldToComparison;
    }

    public List<Map<String, String>> calculateStatistics(String goldBlocksJson, String postProcessedBlocksJson) {
        List<Map<String, Object>> goldBlocks =
                GsonUtils.GSON.fromJson(goldBlocksJson, new TypeToken<List<Map<String, Object>>>() {
                }.getType());
        //System.out.println("json: " + postProcessedBlocksJson);
        List<Map<String, Object>> processedBlocks =
                GsonUtils.GSON.fromJson(postProcessedBlocksJson, new TypeToken<List<Map<String, Object>>>() {
                }.getType());

        int maxBlocks = Math.max(goldBlocks.size(), processedBlocks.size());
        for (int i = goldBlocks.size(); i < maxBlocks; i++) {
            goldBlocks.add(createEmptyBlock(blockFields));
        }
        for (int i = processedBlocks.size(); i < maxBlocks; i++) {
            processedBlocks.add(createEmptyBlock(blockFields));
        }

        List<Map<String, String>> statRecords = new LinkedList<>();
        
        

        for (int i = 0; i < maxBlocks; i++) {
            Map<String, Object> goldBlock = goldBlocks.get(i);
            Map<String, Object> processedBlock = processedBlocks.get(i);
            
            System.out.println("gold: " + goldBlock);
            System.out.println("processed: " + processedBlock);
            
            if(i == 0)
            {
            	for (String constantField : constantFields) {
                    BiFunction<String, String, Boolean> comparison = fieldToComparison.getOrDefault(constantField, String::equalsIgnoreCase);
                    Map<String, String> result =
                            createResult(goldBlock.getOrDefault(constantField, "").toString(), processedBlock.getOrDefault(constantField, "").toString(), comparison);
                    result.put("field", constantField);
                    statRecords.add(result);
                }
            }
            for (String blockField : blockFields) {
                BiFunction<String, String, Boolean> comparison = fieldToComparison.getOrDefault(blockField, String::equalsIgnoreCase);
                Map<String, String> result =
                        createResult(goldBlock.getOrDefault(blockField, "").toString(), processedBlock.getOrDefault(blockField, "").toString(), comparison);
                result.put("field", blockField);
                result.put(HtmlTagAttr.BLOCK_NUMBER, String.valueOf(i));
                statRecords.add(result);
            }

            List<Map<String, String>> goldBlockGroups = (List<Map<String, String>>) goldBlock.getOrDefault(mainGroupField, new LinkedList<Map<String, String>>());
            List<Map<String, String>> processedBlockGroups = (List<Map<String, String>>) processedBlock.getOrDefault(mainGroupField, new LinkedList<Map<String, String>>());

            int maxGroups = Math.max(goldBlockGroups.size(), processedBlockGroups.size());
            for (int j = goldBlockGroups.size(); j < maxGroups; j++) {
                goldBlockGroups.add(createEmptyGroup(groupFields));
            }
            for (int j = processedBlockGroups.size(); j < maxGroups; j++) {
                processedBlockGroups.add(createEmptyGroup(groupFields));
            }

            
            for (int j = 0; j < maxGroups; j++) {
            	Map<String, String> goldGroup = goldBlockGroups.get(j);
            	Map<String, String> processedGroup = processedBlockGroups.get(j);
                for (String groupField : groupFields) {
                    BiFunction<String, String, Boolean> comparison = fieldToComparison.getOrDefault(groupField, String::equalsIgnoreCase);
                    Map<String, String> result =
                            createResult(goldGroup.getOrDefault(groupField, "").toString(), processedGroup.getOrDefault(groupField, "").toString(), comparison);
                    result.put("field", groupField);
                    result.put(HtmlTagAttr.BLOCK_NUMBER, String.valueOf(i));
                    result.put(HtmlTagAttr.TAB_NUMBER, String.valueOf(j));
                    statRecords.add(result);
                }
            }
        }

        return statRecords;
    }

    private Map<String, String> createResult(String goldValue, String processedValue,
                                             BiFunction<String, String, Boolean> comparison) {
        Map<String, String> result = new LinkedHashMap<>();
        result.put("gold", goldValue);
        result.put("extracted", processedValue);
        result.put("tp", "0");
        result.put("fp", "0");
        result.put("fn", "0");
        result.put("tn", "0");
        if ("n/a".equalsIgnoreCase(goldValue)) {
        	goldValue = "";
        }
        if ("n/a".equalsIgnoreCase(processedValue)) {
        	processedValue = "";
        }
        boolean matches = comparison.apply(goldValue, processedValue);
        if (matches) {
            if (StringUtils.isEmpty(goldValue)) {
                result.put("tn", "1");
            } else {
                result.put("tp", "1");
            }
        } else {
            if (StringUtils.isEmpty(goldValue)) {
                result.put("fp", "1");
            } else if (StringUtils.isEmpty(processedValue))  {
            	result.put("fn", "1");
            }
            else {
                result.put("fp", "1");
                result.put("fn", "1");
            }
        }
        return result;
    }

    private Map<String, Object> createEmptyBlock(Set<String> blockFields) {
        Map<String, Object> block = new LinkedHashMap<>();
        for (String blockField : blockFields) {
            block.put(blockField, StringUtils.EMPTY);
        }
        return block;
    }

    private Map<String, String> createEmptyGroup(Set<String> groupFields) {
        Map<String, String> group = new LinkedHashMap<>();
        for (String groupField : groupFields) {
            group.put(groupField, StringUtils.EMPTY);
        }
        return group;
    }
    
    private boolean isZero(String s) {
    	s = s.trim();
    	return "0".equals(s) || "0.00".equals(s) || ".00".equals(s);
    }
}
